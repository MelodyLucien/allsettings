import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;

#parse("File Header.java") 
public class ${class_name}Service extends Service {

    public static final String TAG = ${class_name}Service.class.getSimpleName();
    public static final int ${ServiceTag}_INIT = 1;
    public static final int ${ServiceTag}_STOP = 2;

    private InnerHandler mHandler;
    private HandlerThread mHandlerThread;

    private class InnerHandler extends Handler {

        InnerHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ${ServiceTag}_INIT:
                    init();
                    break;
                case${ServiceTag}_STOP:
                    onStop();
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 初始化应用信息
     */
    private static void init() {
    }

    private void onStop() {
        if (mHandlerThread != null) {
            mHandlerThread.quit();
            if (mHandler != null) {
                mHandler = null;
            }
        }
        stopSelf();
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public boolean stopService(Intent name) {
        onStop();
        return super.stopService(name);
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mHandlerThread = new HandlerThread(TAG);
        mHandlerThread.start();
        mHandler = new InnerHandler(mHandlerThread.getLooper());
    }
}
